// In the Xcode, if you want to load txt file, you have to click Product -> Scheme -> Edit Scheme -> Run -> options -> Working Directory -> use custom working directory and select the folder you need. Then you can input data from txt file
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <vector>
using namespace std;
int main()
{
     ifstream fin;
     ofstream fout;
     fin.open("a_example copy.txt");
     vector<int>slices(500);
     vector<int>save;
     vector<int>index;
     int maximum = 0,temp =0;
     int i = 0,k = 1,total = 0,j = 0;
     int type;
     while (!fin.eof())
     {
        fin >> slices.at(j);
        //cout <<slices.at(j)<< endl;
        j++;
     }
     fin.close();
     type = slices.at(1);
     maximum = slices.at(0);
     slices.erase(slices.begin(),slices.begin()+2);
     temp = maximum - slices.at(type-1);
     save.push_back(slices.at(type-1));
     index.push_back(type-1);
     for(i = type-2 ;i >= 0; i--){
        if(slices.at(i) <= temp){
            temp = temp -slices.at(i);
            save.push_back(slices.at(i));
            index.push_back(i);
            k = k + 1;
        }
        else{
            continue;
        }
    }
    sort(save.begin(),save.end());
    sort(index.begin(),index.end());
    for(i = 0; i < save.size(); i++){
        total = total + save.at(i);
    }
    cout<<"type number: "<<k<<endl;
    cout<<"index: ";
    for(i = 0;i < index.size();i++){
        cout<<index.at(i)<<' ';
    }
    cout<<endl;
    fout.open("output_a.txt");
    fout << k << endl;
    for(i = 0;i < index.size();i++){
        fout<<index.at(i)<<' ';
    }
    fout.close();
    return 0;
}
