// In the Xcode, if you want to load txt file, you have to click Product -> Scheme -> Edit Scheme -> Run -> options -> Working Directory -> use custom working directory and select the folder you need. Then you can input data from txt file
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <vector>
using namespace std;
int main() {
    ifstream fin;
    ofstream fout;
    fin.open("c_medium copy.txt");
    vector<int>save;
    vector<int>index;
    vector<int>slices;
    int maximum = 0,temp =0;
    int i = 0,k = 1,j = 0,total = 0;
    int type;
    int array[1];
    while (!fin.eof())
    {
        fin >> array[0];
        slices.push_back(array[0]);
        //cout <<slices.at(i)<< endl;
        i++;
    }
    fin.close();
    type = slices.at(1);
    maximum = slices.at(0);
    slices.erase(slices.begin(),slices.begin()+2);
    
    fout.open("output_c.txt");
    for(j = 0; j < type; j++){
        save.clear();
        index.clear();
        total = 0;
        k = 1;
        temp = maximum - slices.at(type-j-1);
        save.push_back(slices.at(type-j-1));
        index.push_back(type-j-1);
        for(i = type-j-2;i >= 0 ;i--){
            if(slices.at(i) <= temp){
                temp = temp -slices.at(i);
                save.push_back(slices.at(i));
                index.push_back(i);
                k = k + 1;
            }
            else{
                continue;
            }
        }
        sort(save.begin(),save.end());
        sort(index.begin(),index.end());
        for(i = 0; i < save.size(); i++){
            total = total + save.at(i);
        }
        if(total == 4500){
            cout<<"type number: "<<k<<endl;
            cout<<"index: ";
            for(i = 0;i < index.size();i++){
                cout<<index.at(i)<<' ';
            }
            fout << k << endl;
            for(i = 0;i < index.size();i++){
                fout<<index.at(i)<<' ';
            }
            fout<<endl<<endl;
        }
    }
    cout<<endl;
    fout.close();
    return 0;
}
