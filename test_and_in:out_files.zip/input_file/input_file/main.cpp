#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <vector>
using namespace std;
int main()
{
    ifstream fin;
    ofstream fout;
    //fin.open("d_quite_big copy.txt");
    fin.open("c_medium copy.txt");
    vector<int>save(10000000);
    int j = 0,i = 0;
    while (!fin.eof())
    {
        fin >> save.at(j);
        cout <<save.at(j)<< endl;
        j++;
    }
    fin.close();
    save.erase(save.begin()+j,save.begin()+10000000);
    fout.open("output_c.txt");
    for(i = 0;i < j-1;i++){
        fout << save.at(i)<<endl;
    }
    fout.close();
    return 0;
}
