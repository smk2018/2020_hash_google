#include <iostream>
#include <vector>
using namespace std;
int main() {
    int maximum = 100,temp =0;
    int i = 0,k = 1,j = 0,total = 0;
    const int type =10;
    vector<int>slices = {4,14,15,18,29,32,36,82,95,95};
    vector<int>save;
    vector<int>index;
    for(j = 0; j < type; j++){
        save.clear();
        index.clear();
        total = 0;
        k = 1;
        temp = maximum - slices.at(type-j-1);
        save.push_back(slices.at(type-j-1));
        index.push_back(type-j-1);
        for(i = type-j-2;i >= 0 ;i--){
            if(slices.at(i) <= temp){
                temp = temp -slices.at(i);
                save.push_back(slices.at(i));
                index.push_back(i);
                k = k + 1;
            }
            else{
                continue;
            }
        }
        sort(save.begin(),save.end());
        sort(index.begin(),index.end());
        for(i = 0; i < save.size(); i++){
            total = total + save.at(i);
        }
        if(total == 100){
            cout<<"type number: "<<k<<endl;
            cout<<"index: ";
            for(i = 0;i < index.size();i++){
                cout<<index.at(i)<<' ';
            }
            cout<<endl<<endl;
        }
    }
    return 0;
}
