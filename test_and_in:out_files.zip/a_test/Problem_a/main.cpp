#include <iostream>
#include <vector>
using namespace std;
int main() {
    int maximum = 17,temp =0;
    int i = 0,k = 1,total = 0;
    const int type =4;
    vector<int>slices = {2,5,6,8};
    vector<int>save;
    vector<int>index;
    temp = maximum - slices.at(type-1);
    save.push_back(slices.at(type-1));
    index.push_back(type-1);
    for(i = type-2 ;i >= 0; i--){
       if(slices.at(i) <= temp){
           temp = temp -slices.at(i);
           save.push_back(slices.at(i));
           index.push_back(i);
           k = k + 1;
       }
       else{
           continue;
       }
   }
    sort(save.begin(),save.end());
    sort(index.begin(),index.end());
    for(i = 0; i < save.size(); i++){
        total = total + save.at(i);
    }
    cout<<"type number: "<<k<<endl;
    cout<<"index: ";
    for(i = 0;i < index.size();i++){
        cout<<index.at(i)<<' ';
    }
    cout<<endl;
    return 0;
}
