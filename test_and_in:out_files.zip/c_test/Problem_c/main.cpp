#include <iostream>
#include <vector>
using namespace std;
int main() {
    int maximum = 4500,temp =0;
    int i = 0,k = 1,j = 0,total = 0;
    const int type =50;
    vector<int>slices = {7,12,12,13,14,28,29,29,30,32,32,34,41,45,46,56,61,61,62,63,65,68,76,77,77,92,93,94,97,103,113,114,114,120,135,145,145,149,156,157,160,169,172,179,184,185,189,194,195,195};
    vector<int>save;
        vector<int>index;
        for(j = 0; j < type; j++){
            save.clear();
            index.clear();
            total = 0;
            k = 1;
            temp = maximum - slices.at(type-j-1);
            save.push_back(slices.at(type-j-1));
            index.push_back(type-j-1);
            for(i = type-j-2;i >= 0 ;i--){
                if(slices.at(i) <= temp){
                    temp = temp -slices.at(i);
                    save.push_back(slices.at(i));
                    index.push_back(i);
                    k = k + 1;
                }
                else{
                    continue;
                }
            }
            sort(save.begin(),save.end());
            sort(index.begin(),index.end());
            for(i = 0; i < save.size(); i++){
                total = total + save.at(i);
            }
            if(total == 4500){
                cout<<"type number: "<<k<<endl;
                cout<<"index: ";
                for(i = 0;i < index.size();i++){
                    cout<<index.at(i)<<' ';
                }
                cout<<endl<<endl;
            }
        }
        return 0;
    }

